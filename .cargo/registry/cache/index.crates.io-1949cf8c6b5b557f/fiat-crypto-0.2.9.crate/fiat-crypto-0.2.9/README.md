## Fiat-crypto

This crate provides the extracted Rust code from the Coq
[fiat-crypto](https://github.com/mit-plv/fiat-crypto) libraries.


## License
This project is distributed under the terms of the MIT License, the Apache License (Version 2.0), and the BSD 1-Clause License; users may pick which license to apply.

See [`COPYRIGHT`](COPYRIGHT), [`LICENSE-MIT`](LICENSE-MIT), [`LICENSE-APACHE`](LICENSE-APACHE), and [`LICENSE-BSD-1`](LICENSE-BSD-1) for details.
