# TODO

  - `BitsMutExt` trait:
      - methods `bit_assign`, `bit_zip_assign`, `bit_xor_assign`, 
      etc.
    
  - Conversions between `Block` types:
      - bit-wise adapter
      - block-wise?
    
  - Shifts and rotations:
      - functional
      - in-place

  - `SparseBitVec`
  
  - Always more performance comparisons.
  
