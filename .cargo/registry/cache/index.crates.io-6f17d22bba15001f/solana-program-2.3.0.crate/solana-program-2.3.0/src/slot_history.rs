#[deprecated(since = "2.1.0", note = "Use `solana-slot-history` crate instead")]
pub use {solana_clock::Slot, solana_slot_history::*};
