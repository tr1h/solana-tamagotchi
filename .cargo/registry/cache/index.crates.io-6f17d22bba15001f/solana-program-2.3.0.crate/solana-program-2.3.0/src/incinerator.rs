#[deprecated(since = "2.2.0", note = "Use `solana_sdk_ids::incinerator` instead")]
pub use solana_sdk_ids::incinerator::{check_id, id, ID};
